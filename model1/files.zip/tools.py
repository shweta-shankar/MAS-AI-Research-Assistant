# tools.py — Repository interaction tools for the agent

import re
import requests
from config import GITINGEST_API_URL, SEARCH_TOP_K, CHUNK_SIZE

# In-memory store for the current session's repo data
# Format: { "file/path.py": ["line1\n", "line2\n", ...] }
_repo_store = {}
_raw_dump = ""  # Full raw text from gitingest


# ── 1. FETCH REPO ────────────────────────────────────────────────────────────

def fetch_repo(github_url: str) -> str:
    """
    Pulls a GitHub repo through gitingest and stores it in memory.
    Call this once at the start of a session.
    Returns a status message.
    """
    global _repo_store, _raw_dump

    try:
        # gitingest accepts a GitHub URL and returns a structured text dump
        response = requests.post(
            f"{GITINGEST_API_URL}/api/ingest",
            json={"url": github_url},
            timeout=60
        )
        response.raise_for_status()
        _raw_dump = response.text

        # Parse the dump into per-file chunks
        _repo_store = _parse_gitingest_dump(_raw_dump)

        return f"Repo loaded successfully. {len(_repo_store)} files indexed."

    except requests.RequestException as e:
        return f"Error fetching repo: {str(e)}"


def _parse_gitingest_dump(dump: str) -> dict:
    """
    Parses gitingest output into a dict of {filepath: [lines]}.
    gitingest separates files with a header like:
        ================================================
        File: path/to/file.py
        ================================================
    """
    file_store = {}
    # Split on file boundaries
    sections = re.split(r"={40,}", dump)

    for i, section in enumerate(sections):
        # Look for a "File: ..." header
        match = re.match(r"\s*File:\s*(.+?)\s*\n", section)
        if match:
            filepath = match.group(1).strip()
            content = section[match.end():]
            file_store[filepath] = content.splitlines(keepends=True)

    return file_store


# ── 2. SEARCH REPO ───────────────────────────────────────────────────────────

def search_repo(query: str) -> list[dict]:
    """
    Searches all indexed files for lines matching the query.
    Returns up to SEARCH_TOP_K results, each with file path, line number, and snippet.

    Each result format:
    {
        "file": "src/utils/parser.py",
        "line_start": 45,
        "line_end": 52,
        "snippet": "...matching lines..."
    }
    """
    if not _repo_store:
        return [{"error": "No repo loaded. Call fetch_repo() first."}]

    results = []
    query_lower = query.lower()

    for filepath, lines in _repo_store.items():
        for i, line in enumerate(lines):
            if query_lower in line.lower():
                # Grab a window of lines around the match for context
                start = max(0, i - 2)
                end = min(len(lines), i + CHUNK_SIZE)
                snippet = "".join(lines[start:end])

                results.append({
                    "file": filepath,
                    "line_start": start + 1,  # 1-indexed for readability
                    "line_end": end,
                    "snippet": snippet.strip()
                })

                if len(results) >= SEARCH_TOP_K:
                    return results

    return results if results else [{"message": f"No results found for: '{query}'"}]


# ── 3. OPEN FILE ─────────────────────────────────────────────────────────────

def open_file(filepath: str) -> dict:
    """
    Returns the full content of a specific file with line numbers.
    Result format:
    {
        "file": "src/utils/parser.py",
        "total_lines": 120,
        "content": "   1 | def parse(...):\n   2 |     ..."
    }
    """
    if not _repo_store:
        return {"error": "No repo loaded. Call fetch_repo() first."}

    if filepath not in _repo_store:
        # Try a fuzzy match in case the LLM got the path slightly wrong
        matches = [f for f in _repo_store if filepath in f]
        if not matches:
            return {"error": f"File not found: {filepath}"}
        filepath = matches[0]  # Use the closest match

    lines = _repo_store[filepath]
    numbered = "".join(f"{i+1:4} | {line}" for i, line in enumerate(lines))

    return {
        "file": filepath,
        "total_lines": len(lines),
        "content": numbered
    }


# ── 4. LIST FILES ─────────────────────────────────────────────────────────────

def list_files(directory: str = "") -> dict:
    """
    Lists all indexed files, optionally filtered by directory prefix.
    Result format:
    {
        "directory": "src/",
        "files": ["src/main.py", "src/utils/parser.py", ...]
    }
    """
    if not _repo_store:
        return {"error": "No repo loaded. Call fetch_repo() first."}

    all_files = list(_repo_store.keys())

    if directory:
        filtered = [f for f in all_files if f.startswith(directory)]
    else:
        filtered = all_files

    return {
        "directory": directory or "(root)",
        "files": sorted(filtered)
    }


# ── TOOL REGISTRY (used by agent.py) ─────────────────────────────────────────

TOOLS = {
    "search_repo": search_repo,
    "open_file": open_file,
    "list_files": list_files,
}

# agent.py — Core agent loop and Ollama interface

import re
import json
import requests
from config import OLLAMA_MODEL, OLLAMA_BASE_URL, MAX_ITERATIONS, MAX_TOKENS, REQUIRE_CITATIONS
from tools import TOOLS
from prompts import SYSTEM_PROMPT, build_user_message, build_tool_result_message


# ── OLLAMA INTERFACE ──────────────────────────────────────────────────────────

def call_ollama(messages: list[dict]) -> str:
    """
    Sends a message history to the local Ollama model and returns the response text.
    """
    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "options": {
            "num_predict": MAX_TOKENS,
        }
    }

    try:
        response = requests.post(
            f"{OLLAMA_BASE_URL}/api/chat",
            json=payload,
            timeout=120
        )
        response.raise_for_status()
        data = response.json()
        return data["message"]["content"]

    except requests.RequestException as e:
        return f"Error calling Ollama: {str(e)}"


# ── RESPONSE PARSER ───────────────────────────────────────────────────────────

def parse_action(response_text: str) -> tuple[str, dict] | None:
    """
    Parses the LLM's response to extract a tool call action.
    Returns (action_name, params_dict) or None if no action found.

    Expected LLM format:
        ACTION: search_repo
        QUERY: some search term

        ACTION: open_file
        FILE: src/utils/parser.py

        ACTION: answer
        ANSWER: The system does X [file.py:10-20]...
    """
    lines = response_text.strip().splitlines()
    action = None
    params = {}

    for line in lines:
        line = line.strip()
        if line.startswith("ACTION:"):
            action = line.split("ACTION:", 1)[1].strip().lower()
        elif line.startswith("QUERY:"):
            params["query"] = line.split("QUERY:", 1)[1].strip()
        elif line.startswith("FILE:"):
            params["filepath"] = line.split("FILE:", 1)[1].strip()
        elif line.startswith("DIRECTORY:"):
            params["directory"] = line.split("DIRECTORY:", 1)[1].strip()
        elif line.startswith("ANSWER:"):
            params["answer"] = line.split("ANSWER:", 1)[1].strip()

    if action:
        return action, params
    return None


# ── CITATION VERIFIER ─────────────────────────────────────────────────────────

def verify_citations(answer: str, retrieved_files: set) -> dict:
    """
    Checks that every citation in the answer references a file
    that was actually retrieved during this session.

    Returns:
    {
        "valid": True/False,
        "citations_found": [...],
        "unverified": [...]   # citations pointing to files not retrieved
    }
    """
    # Find all citations like [path/to/file.py:10-25]
    citation_pattern = r'\[([^\]]+\.[\w]+:\d+-\d+)\]'
    citations = re.findall(citation_pattern, answer)

    unverified = []
    for citation in citations:
        filepath = citation.split(":")[0]
        if filepath not in retrieved_files:
            unverified.append(citation)

    return {
        "valid": len(unverified) == 0,
        "citations_found": citations,
        "unverified": unverified
    }


# ── MAIN AGENT LOOP ───────────────────────────────────────────────────────────

def run_agent(question: str) -> dict:
    """
    Runs the full agent loop for a given question.
    Returns:
    {
        "answer": "...",
        "citations": [...],
        "verified": True/False,
        "unverified_citations": [...],
        "iterations": N,
        "tool_calls": [...]
    }
    """
    # Build initial message history
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": build_user_message(question)}
    ]

    retrieved_files = set()   # Track which files were opened this session
    tool_calls_log = []       # Log of all tool calls made
    final_answer = None

    for iteration in range(MAX_ITERATIONS):
        print(f"\n[Agent] Iteration {iteration + 1}/{MAX_ITERATIONS}")

        # Call the LLM
        response_text = call_ollama(messages)
        print(f"[LLM Response]\n{response_text}\n")

        # Append LLM response to history
        messages.append({"role": "assistant", "content": response_text})

        # Parse the action
        parsed = parse_action(response_text)

        if not parsed:
            print("[Agent] No action detected. Prompting LLM to continue...")
            messages.append({
                "role": "user",
                "content": "Please continue. Use one of the available actions: search_repo, open_file, list_files, or answer."
            })
            continue

        action, params = parsed

        # ── Handle: answer ────────────────────────────────────────────────
        if action == "answer":
            final_answer = params.get("answer", response_text)
            break

        # ── Handle: tool calls ────────────────────────────────────────────
        tool_fn = TOOLS.get(action)
        if not tool_fn:
            tool_result = f"Unknown tool: {action}"
        else:
            # Execute the tool
            try:
                tool_result = tool_fn(**params)
                tool_calls_log.append({"action": action, "params": params})

                # Track opened files for citation verification
                if action == "open_file" and "filepath" in params:
                    retrieved_files.add(params["filepath"])
                elif action == "search_repo" and isinstance(tool_result, list):
                    for r in tool_result:
                        if "file" in r:
                            retrieved_files.add(r["file"])

            except Exception as e:
                tool_result = f"Tool error: {str(e)}"

        # Feed result back to LLM
        result_str = json.dumps(tool_result, indent=2) if not isinstance(tool_result, str) else tool_result
        messages.append({
            "role": "user",
            "content": build_tool_result_message(action, result_str)
        })

    # If loop exhausted without an answer
    if not final_answer:
        final_answer = "Agent reached maximum iterations without producing a final answer."

    # Verify citations if required
    verification = verify_citations(final_answer, retrieved_files) if REQUIRE_CITATIONS else {
        "valid": None, "citations_found": [], "unverified": []
    }

    return {
        "answer": final_answer,
        "citations": verification["citations_found"],
        "verified": verification["valid"],
        "unverified_citations": verification["unverified"],
        "iterations": iteration + 1,
        "tool_calls": tool_calls_log
    }
